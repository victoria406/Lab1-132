package org.example;

import junit.framework.TestCase;
import org.junit.Test;

public class CalculatorTestEasy extends TestCase {
    @Test
    public void testingThreePower(){
        Calculator calculator =new Calculator();
        assertEquals(9.882117688026186, calculator.calcPower(2.5,2.5));
    }
}